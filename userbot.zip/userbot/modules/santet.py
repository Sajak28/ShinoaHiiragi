import asyncio
import re
import time
from time import sleep
from userbot import CMD_HELP, ZALG_LIST
from userbot.events import register

@register(outgoing=True, pattern='^.santet(?: |$)(.*)')
async def typewriter(typew):
	message = typew.pattern_match.group(1)
	await typew.edit("Sedang Menyantet Korban...\nMampus Kau Anjeng!")
	sleep(5)
	await typew.edit("Sedang Mencari Informasi Korban...")
	sleep(5)
	await typew.edit("Informasi Ditemukan...\nMengirim Santet Diproses!")
	sleep(5)
	await typew.edit("0%")
	number = 1
	await typew.edit(str(number) + "%\nProses Santet...\n▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████████")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████████▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████████▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████████▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████████▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████████▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████████")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████████▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████████▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████████▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████████▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████████▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████████")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████████▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████████▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████████▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████████▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████████▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████████")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████████▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████████▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████████▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████████▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████████▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████████████")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████████████▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████████████▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████████████▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████████████▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n█████████████▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████████████")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████████████▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████████████▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████████████▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████████████▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n██████████████▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████████████")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████████████▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████████████▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████████████▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████████████▊")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n███████████████▉")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████████████")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████████████▎")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████████████▍")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████████████▌")
	number = number+ 1
	sleep(0.01)
	await typew.edit(str(number) + "%\nProses Santet...\n████████████████▌")
	sleep(1)
	await typew.edit("Korban Berhasil Disantet")
	sleep(5)
	await typew.edit("Tapi Boong, Hiyak Hiyak Hiyak!")
	# Karyaku sendiri by @AkameNFS


CMD_HELP.update({
  "santet": 
  ".santet \
 \nKegunaan: Untuk Menyantet Korban, Tapi Ini Hanya Tipuan.\n"
 })





